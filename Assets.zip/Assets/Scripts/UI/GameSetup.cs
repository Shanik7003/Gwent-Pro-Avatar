using System.Collections;
using System.Collections.Generic;
using Engine;
using UnityEngine;

// public class GameSetup : MonoBehaviour
// {
//     // Start is called before the first frame update
//     void Start()
//     {
//         _ = new Game();
//     }

   
// }
